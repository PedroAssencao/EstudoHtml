import Button from './components/buttons/index'
function App() {
  return (
    <div className='row g-0 m-0 gap-0 bg-dark'>

      <div className='col-3'>
        <Button Teste='1' />

      </div><div className='col-3'>
        <Button Teste='1' />

      </div><div className='col-3'>
        <Button Teste='1' />

      </div><div className='col-3'>
        <Button Teste='1' />
      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div>
      <div className='col'>
        <Button Teste='1' />

      </div><div className='col'>
        <Button Teste='1' />

      </div>
    </div>
  )
}

export default App
