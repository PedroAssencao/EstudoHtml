import './style.css'
function Button(index){
    return(
        <div className='BtnNumero'>
            {index.Teste}
        </div>
    )
}
export default Button;